import os
from PIL import Image, ImageDraw, ImageFont, ImageFilter

W, H = 1080, 1350

def create_hero_banner():
    im_white = Image.open('assets/nkb-tshirt-004-3.png').convert('RGBA')
    im_black = Image.open('assets/nkb-tshirt-004-5.png').convert('RGBA')
    logo = Image.open('assets/logo.png').convert('RGBA')
    
    # 1. Base model (white tee)
    crop_h = int(1024 * (H / W))
    base = im_white.crop((0, 20, 1024, 20 + crop_h)).resize((W, H), Image.Resampling.LANCZOS)
    
    canvas = Image.new('RGBA', (W, H))
    canvas.paste(base, (0, 0))
    
    # 2. Add smooth bottom gradient overlay for readability
    gradient = Image.new('RGBA', (W, H), (0, 0, 0, 0))
    g_draw = ImageDraw.Draw(gradient)
    start_y = int(H * 0.60)
    for y in range(start_y, H):
        ratio = (y - start_y) / float(H - start_y)
        alpha = int(220 * (ratio ** 1.2))
        g_draw.line([(0, y), (W, y)], fill=(10, 10, 10, alpha))
        
    # Top subtle gradient for contrast
    top_h = int(H * 0.18)
    for y in range(0, top_h):
        ratio = 1.0 - (y / float(top_h))
        alpha = int(120 * (ratio ** 1.2))
        g_draw.line([(0, y), (W, y)], fill=(10, 10, 10, alpha))
        
    canvas = Image.alpha_composite(canvas, gradient)
    
    # 3. Logo at top left inside a sleek glass pill
    bbox = logo.split()[-1].getbbox()
    c_logo = logo.crop(bbox)
    logo_w = 240
    logo_h = int(c_logo.height * (logo_w / float(c_logo.width)))
    c_logo = c_logo.resize((logo_w, logo_h), Image.Resampling.LANCZOS)
    
    pill_w = logo_w + 32
    pill_h = logo_h + 18
    # Glass pill
    pill = Image.new('RGBA', (pill_w, pill_h), (255, 255, 255, 240))
    p_draw = ImageDraw.Draw(pill)
    p_draw.rounded_rectangle([(0,0), (pill_w, pill_h)], radius=12, outline=(198, 154, 58, 200), width=2)
    canvas.paste(pill, (40, 36), pill)
    canvas.paste(c_logo, (56, 45), c_logo)
    
    # 4. Inset card at top right: Alternate colorway (Noir Black Tee)
    inset_w, inset_h = 210, 260
    b_crop = im_black.crop((180, 180, 840, 990)).resize((inset_w, inset_h), Image.Resampling.LANCZOS)
    
    mask = Image.new('L', (inset_w, inset_h), 0)
    m_draw = ImageDraw.Draw(mask)
    m_draw.rounded_rectangle([(0,0), (inset_w, inset_h)], radius=16, fill=255)
    
    inset_pos = (W - inset_w - 40, 36)
    # Outline frame
    frame = Image.new('RGBA', (inset_w + 6, inset_h + 6), (0,0,0,0))
    f_draw = ImageDraw.Draw(frame)
    f_draw.rounded_rectangle([(0,0), (inset_w + 6, inset_h + 6)], radius=18, fill=(198, 154, 58, 255))
    canvas.paste(frame, (inset_pos[0]-3, inset_pos[1]-3), frame)
    canvas.paste(b_crop, inset_pos, mask)
    
    # Inset badge: 'NOIR BLACK'
    f_badge = ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf', 16)
    badge_bg = Image.new('RGBA', (inset_w, 36), (8, 8, 8, 220))
    canvas.paste(badge_bg, (inset_pos[0], inset_pos[1] + inset_h - 36))
    draw = ImageDraw.Draw(canvas)
    draw.text((inset_pos[0] + 32, inset_pos[1] + inset_h - 28), 'NOIR BLACK EDIT', fill=(231, 200, 117), font=f_badge)

    # 5. Bottom banner typography (Editorial & E-commerce Style)
    f_tag = ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf', 20)
    f_title = ImageFont.truetype('C:/Windows/Fonts/georgiab.ttf', 48)
    f_sub = ImageFont.truetype('C:/Windows/Fonts/segoeui.ttf', 21)
    f_price = ImageFont.truetype('C:/Windows/Fonts/segoeuib.ttf', 34)
    
    # Gold decorative separator line
    draw.line([(50, H - 210), (W - 50, H - 210)], fill=(198, 154, 58, 230), width=2)
    
    # Small campaign tag
    draw.rounded_rectangle([(50, H - 250), (280, H - 218)], radius=6, fill=(198, 154, 58, 240))
    draw.text((64, H - 245), '🔥 2026 SIGNATURE DROP', fill=(8, 8, 8), font=f_tag)
    
    draw.text((50, H - 195), 'OVERSIZED STREETWEAR TEES', fill=(255, 255, 255), font=f_title)
    draw.text((50, H - 130), '240 GSM COMBED BIO-WASH COTTON  •  PRE-SHRUNK  •  HD PRINTS', fill=(215, 210, 200), font=f_sub)
    draw.text((50, H - 90), 'MADE IN NASHIK  |  PAN-INDIA EXPRESS DELIVERY', fill=(198, 154, 58), font=f_sub)
    
    # Price tag on the right
    draw.text((W - 250, H - 170), 'JUST ₹599', fill=(231, 200, 117), font=f_price)
    draw.text((W - 250, H - 128), 'MRP ₹1,199 (50% OFF)', fill=(170, 165, 155), font=f_sub)
    
    # Save as WebP and PNG
    final_rgb = canvas.convert('RGB')
    final_rgb.save('assets/hero-banner.webp', 'WEBP', quality=90)
    final_rgb.save('assets/hero-banner.png', 'PNG')
    print('Generated assets/hero-banner.webp and assets/hero-banner.png successfully!')

if __name__ == '__main__':
    create_hero_banner()
